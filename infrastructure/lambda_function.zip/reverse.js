'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = reverse;
function reverse(string) {
  return string.split('').reverse().join('');
}