'use strict';

var _reverse = require('./reverse');

var _reverse2 = _interopRequireDefault(_reverse);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.handler = (event, context, callback) => {
  console.log('Hello, logs!');
  console.log((0, _reverse2.default)('hoang nam'));
  callback(null, 'great success');
};