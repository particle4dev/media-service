'use strict';

var _awsServerlessExpress = require('aws-serverless-express');

var _awsServerlessExpress2 = _interopRequireDefault(_awsServerlessExpress);

var _app = require('./app');

var _app2 = _interopRequireDefault(_app);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const server = _awsServerlessExpress2.default.createServer(_app2.default);
exports.handler = (event, context) => _awsServerlessExpress2.default.proxy(server, event, context);